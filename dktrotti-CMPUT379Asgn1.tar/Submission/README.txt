Name: Dominic Trottier
ID: 1367571
CCID: dktrotti
Lecture: EA1
Instructor: Paul Lu
Lab: ED04
TA: Luke Nitish Kumar

Procnanny is a simple program that will monitor specified processes to ensure
that they do not run for longer than a specified time. These parameters can
be specified in a text file with the number of seconds as the first line, then
each process to be monitored on separate lines. The location of this
configuration file should be passed as the first and only argument to 
procnanny.

In order to run procnanny, first navigate to the folder containing the
included file called 'Makefile' and 'procnanny.c'. Run the command 'make' and
an executable called 'procnanny should be created. Run this executable with
the location of the configuration file as the first argument.
